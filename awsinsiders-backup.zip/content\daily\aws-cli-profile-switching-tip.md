---
title: "AWS CLI Profile Switching Tip"
date: 2025-06-25
tags: ["tip"]
type: "daily"
---
Use `aws configure --profile` to quickly switch credentials across multiple AWS accounts without re-authenticating every time. Save time. Avoid stress. Impress your cloud cat.
