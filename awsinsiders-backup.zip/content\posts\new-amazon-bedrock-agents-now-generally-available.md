---
title: "New – Amazon Bedrock Agents Now Generally Available"
date: 2024-09-15
draft: false
---

Build generative AI applications that can execute tasks using agents.

[Read the full article here](https://aws.amazon.com/blogs/aws/amazon-bedrock-agents-now-generally-available/)
