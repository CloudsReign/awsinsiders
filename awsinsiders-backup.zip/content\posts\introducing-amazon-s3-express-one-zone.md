---
title: "Introducing Amazon S3 Express One Zone"
date: 2024-10-10
draft: false
---

A new high-performance storage class for latency-sensitive applications.

[Read the full article here](https://aws.amazon.com/blogs/aws/introducing-amazon-s3-express-one-zone/)
